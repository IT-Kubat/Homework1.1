package com.company;

public class Main {

    public static void main(String[] args) {

	//
        System.out.println("Привет мир");

        String tx = "Привет";

        System.out.println(tx);

        String myWord = "Привет";

        String myVoice = "Здрасти";
        

        System.out.println("результат соединения:"+ myWord + myVoice );


        final String tx2 = "Привет";
        System.out.println(tx2);












    }
}
